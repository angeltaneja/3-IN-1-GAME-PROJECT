# PlayZone Gaming

A responsive neon arcade built with HTML, CSS, and vanilla JavaScript.

## Run
Open `dist/index.html` directly, or serve the directory:

```sh
python3 -m http.server 4173 --directory dist
```

Visit http://localhost:4173.

## Games
- Flappy Bird: Space, mouse click, or tap to flap.
- Cyber-Tac-Toe: Play against a minimax computer opponent or a friend on the same device.
- Classic Snake: Arrow keys, WASD, swipe, or the on-screen direction buttons.

Use P to pause the arcade games. Scores and your optional player name are stored locally in your browser. There is no backend, account service, or global leaderboard. Google Fonts is optional; local fallback fonts keep the site usable offline. All artwork is drawn with CSS, SVG, or canvas.

## Files
- `dist/index.html`: Page, game dialogs, and player profile.
- `dist/style.css`: Responsive styling and game artwork.
- `dist/app.js`: Game engines, opponent logic, controls, local storage, and hero artwork.
